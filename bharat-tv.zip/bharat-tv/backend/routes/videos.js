
const express = require("express");
const multer = require("multer");
const Video = require("../models/Video");
const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname)
});
const upload = multer({ storage });

router.post("/upload", upload.single("video"), async (req, res) => {
  const { title, description } = req.body;
  const uploaderEmail = req.user?.email || "anonymous";

  const newVideo = new Video({
    title,
    description,
    filename: req.file.filename,
    uploaderEmail
  });

  await newVideo.save();
  res.json({ message: "Video uploaded", url: `/uploads/${req.file.filename}` });
});

router.get("/", async (req, res) => {
  const { search } = req.query;
  const query = search
    ? { $or: [
        { title: new RegExp(search, "i") },
        { description: new RegExp(search, "i") }
      ]}
    : {};
  const videos = await Video.find(query).sort({ uploadedAt: -1 });
  res.json(videos);
});

module.exports = router;
